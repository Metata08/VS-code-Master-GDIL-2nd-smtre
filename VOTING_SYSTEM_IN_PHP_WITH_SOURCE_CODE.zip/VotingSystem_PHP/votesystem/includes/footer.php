<footer class="main-footer">
    <div class="container">
      <div class="pull-right hidden-xs">
        <b>Voting System</b>
      </div>
      <strong> &copy; 2018 Brought To You By<a href="https://code-projects.org/"> Code-Projects</a></strong>
    </div>
    <!-- /.container -->
</footer>