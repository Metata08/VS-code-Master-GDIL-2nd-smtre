<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../fichierCSS/style.css">
    <title>création de compte</title>
</head>
<body>
    <header>
        <h1>AJOUT D'UN NOUVEAU MEDECIN</h1>
    </header>
    <main>
        <form class="maclasse" method="post" action="ajoutM.php">
            <fieldset>
                Les champs marqués d'un astérisque (*) doivent être renseignés.
                <br>
                Cette adresse me servira d'identifiant pour accéder à mon compte
            </fieldset>
            <label>Adresse électronique* :</label>
            <input type="email" name="mail" required>
            <br>
            <E-mail>Confimer l'adresse électronique* :</E-mail>
            <input type="email" name="confMail" required>
            <br>
            <label for="nom">Nom* :</label>
            <input type="text" name="nom" required>
            <br>
            <label for="prenom">Prénom* :</label>
            <input type="text" name="prenom" required>
            <br>
            <label for="age">Age* :</label>
            <input type="number" name="age" required>
            <br>
            <label for="numtel">Numéro de téléphone :</label>
            <input type="tel" name="numtel">
            <br>
            <label for="numlic">Numéro de licence* :</label>
            <input type="tel" name="numlic" required>
            <br>
            <label for="adresse">Adresse* :</label>
            <input type="text" name="adresse">
            <br>
            <label for="specialite">Spécialité* :</label>
            <input type="text" name="specialite" required>
            <br>
            <div>
                <label for="sexe">Sexe</label>
                <input type="radio" name="sexe" value="Homme">Homme
                <input type="radio" name="sexe" value="Femme">Femme
            </div>
            <br>
            <div>
                <button type="reset">Effacer</button>
                <button type="submit" name="valider">Enregistrer</button>
            </div>
        </form>
    </main>
    <footer>&copy; 2023 Sen Médecin</footer>
</body>
</html>