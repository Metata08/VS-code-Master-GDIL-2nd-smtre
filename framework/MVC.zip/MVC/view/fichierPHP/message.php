<?php
    @$id=$_GET['id'];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../fichierCSS/style.css">
    <title>envooie Message</title>
</head>
<body>
    <header>
        <a class="logo" href="../fichierHTML/admin-accueille.html">
            <h5>Sén médecin</h5>
        </a>
        <h1>ENVOYER UN MESSAGE</h1>
    </header>
    <form class="maclasse" action="envoie.php" method="post">
        <label for="user_id">ID du patient :</label>
        <input type="int" value="<?php echo $id ?>">
        <label for="message">Message :</label>
        <textarea name="message" id="message" rows="4" cols="50"></textarea>
        <br>
        <input type="submit" value="Envoyer">
    </form>
</body>
</html>