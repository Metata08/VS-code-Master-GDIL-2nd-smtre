<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../fichierCSS/style.css">
    <title>création de compte</title>
</head>

<body>
    <header>
        <h1>JE M'INSCRIS</h1>
    </header>   
    <form class="maclasse" method="post" action="../../controller/enregistrer_client.php">
        <fieldset>
            Les champs marqués d'un astérisque (*) doivent être renseignés.
            <br>
            Cette adresse me servira d'identifiant pour accéder à mon compte
        </fieldset>
        <E-mail>Adresse électronique* :</E-mail>
        <input type="text" name="mail" value="<?php echo @$mail ?>">
        <br>
        <E-mail>Confimer votre adresse électronique* :</E-mail>
        <input type="text" name="confMail" value="<?php echo @$confMail ?>">
        <br>

        <label>Mot de passe : </label>
        <input type="text" name="mdp" >
        <br>

        <label for="nom">Nom* :</label>
        <input type="text" name="nom" >
        <br>
        <label for="prenom">Prénom* :</label>
        <input type="text" name="prenom" >
        <br>
        <label for="age">Age* :</label>
        <input type="number" name="age">
        <br>
        <label for="numero-de-telephone">Numéro de téléphone :</label>
        <input type="tel" name="numTel"  >
        <br>
        <label for="adresse">Adresse* :</label>
        <input type="text" name="adresse">
        <br>
        <div>
            <label for="sexe">Sexe</label>
            <input type="radio" name="sexe" value="h">Homme
            <input type="radio" name="sexe" value="f">Femme
           <!--  <select name="sexe">
                <option value="h">Homme</option>    
                <option value="f">Femme</option>
            </select> -->
        </div>
        <br>
        <div>
            <button type="reset">Effacer</button>
            <button type="submit" name="valider">S'inscrire</button>
        </div>
    </form>
    <footer>&copy; 2023 Sen Médecin</footer>
</body>

</html>