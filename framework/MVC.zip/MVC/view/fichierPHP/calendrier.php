<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sen Medecin</title>
    <link rel="stylesheet" href="../fichierCSS/calendrier.css">
</head>

<body>
    <header>
        <a href="visiteur.php
            <h1>Sén médecin</h1>
        </a>
        <a href="navbar/propos.html">A propos</a>
        <a href="navbar/services.html">Services</a>
        <a href="navbar/contact.html">Contact</a>
    </header>
    <div class="navbar">
        <ul class="ulbar">
            <img src="../icones/menu.png">
            <li>
                <a href="visiteur.php<img src="../icones/accueil.png">Accueil</a>
            </li>
            <li>
                <a href="list_medecin.php"><img src="../icones/medecin.png">Médecins</a>
            </li>
            <li>
                <a href="notification.php"><img src="../icones/notification.png">Notifications</a>
            </li>
            <li>
                <a href="listereservation.php"><img src="../icones/rendez-vous.png">Mes rendez-vous</a>
            </li>
            <li>

                <a href="historique.php"><img src="../icones/historique.png">Historique</a>
            </li>
        </ul>
    </div>
    <main>
        <div class="user">
            <?php 
            session_start(); 
            if(isset($_SESSION['nom']) && isset($_SESSION['prenom'])) {
                echo '<p>' . $_SESSION['prenom'] . ' ' . $_SESSION['nom'] . '</p>';
            } else {
                echo '<p>USER NAME</p>';
            }
            ?>
        </div>

        <div class="contenair">
            <p>
            <h2> Bienvenue sur notre service de prise de rendez-vous en ligne</h2> <br>

            Nous sommes ravis de vous proposer une manière simple et efficace de planifier vos rendez-vous avec
            nous. <br>Notre formulaire de prise de rendez-vous a été conçu pour vous offrir une expérience
            pratique, rapide et sans tracas. <br>

            <br>Comment ça marche : <br>

            1. Remplissez le formulaire : Indiquez vos coordonnées et les détails de votre rendez-vous. <br>
            2. Choisissez la date et l'heure : Consultez notre calendrier en ligne pour sélectionner le créneau
            qui vous convient le mieux. <br>
            3. Confirmez votre rendez-vous : Une fois que vous avez vérifié les informations, confirmez votre
            rendez-vous. <br>
            <br>Vous recevrez une confirmation par e-mail avec tous les détails nécessaires.

            Besoin d'aide ? Notre équipe est là pour vous assister à chaque étape du processus. <br><a
                href="navbar/contact.html">Contactez-nous</a> si vous avez des questions ou des préoccupations. <br>
            <br>

            Nous sommes impatients de vous accueillir et de rendre votre expérience de réservation aussi simple
            que possible. Merci de choisir notre service de prise de rendez-vous en ligne ! <br>

            </p>
        </div>
        <h2 id="carte">Les medecins proches de votre position</h2>
        <!-- div pour afficher la carte de geolocalisation  -->
        <div id="map"></div>
        <script async defer
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB6sQiiu5V4O4xeHlufXss5g2dM0XAy6jI&callback=initMap">
            </script>

        <form method="get" class="formulaire" id="booking-form">
            <h2 id="presentation">Veillez remplir ce formulaire </h2>
            <div class="maclasse">
                <div class="lab">
                    <label for="specialite" class="lab_description">Spécialité du Médecin :</label>
                    <select id="specialite" required>
                        <option value="null">--- Donner la Spécialité du Medecin---</option>
                        <option value="Cardiologue">Cardiologue</option>
                        <option value="Dermatologue">Dermatologue</option>
                        <option value="Gynécologue">Gynécologue</option>
                        <!-- Ajoutez d'autres spécialités si nécessaire -->
                    </select>

                </div>

                <div class="date-selection">
                    <div class="lab">

                        <label for="date" class="lab_description">Date</label>
                        <input type="date" id="date" required>
                    </div>

                    <div class="lab">
                        <label for="heure" class="lab_description">Heure :</label>
                        <select id="heure" required>
                            <option value="null" selected> --heure du rendez-vous--</option>
                        </select>
                    </div>
                </div>

                <table id="med-table">
                    <!-- Le tableau des médecins et de leur calendrier de disponibilité sera généré ici en JavaScript -->
                </table>
                <!-- À l'intérieur du formulaire -->
                <div id="summary"> </div>
                <div class="but">
                    <button type="submit" id="but-valide"> Valider </button>
                    <button type="reset" id="but-annule">Annuler</button>
                </div>


        </form>
        <script src="../fichierSCRIPT/calendrier.js"></script>
    </main>
    <footer>
        <p><em class="logo">sén médecin</em> copyright © 2023 - Tous droits réservés</p>
        <section class="foot">
            <div>
                <h5>A propos</h5>
                Bienvenue sur sén médecin, votre destination en ligne pour trouver des informations
                précieuses, des ressources utiles et des conseils pratiques dans le domaine de la santé et du
                bien-être. Notre mission est de fournir des contenus fiables et accessibles pour vous aider à
                prendre des décisions éclairées concernant votre santé. <a href="navbar/propos.html">plus</a>
            </div>
            <div>
                <h5>Contactez-nous</h5>
                Nous sommes là pour vous aider. N'hésitez pas à nous contacter pour toute question,
                préoccupation ou suggestion que vous pourriez avoir. Voici comment vous pouvez entrer en
                contact avec nous <a href="navbar/contact.html">plus</a>
            </div>
            <div>
                <h5>Nos services</h5>
                Chez sén médecin, nous sommes dévoués à améliorer votre santé et votre
                bien-être. Découvrez nos services personnalisés conçus pour répondre à vos besoins
                individuels <a href="navbar/services.html">plus</a>
            </div>
        </section>
    </footer>

</body>

</html>