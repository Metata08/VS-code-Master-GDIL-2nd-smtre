<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../fichierCSS/acceuil.css">
    <title>Je me connecte</title>
</head>

<body>
    <header class="tete">
        <a href="../../index.html">
            <h1>Sén médecin</h1>
        </a>
        <a href="../fichierHTML/propos.html">A propos</a>
        <a href="../fichierHTML/services.html">Services</a>
        <a href="../fichierHTML/contact.html">Contact</a>
    </header>
    <main>
        <section id="formu">
            <form name="fo" method="post" action="../../controller/orienter.php">
                <div class="label">Identifiant:</div>
                <input type="text" name="mail" required>
                <div class="label">Mot de passe:</div>
                <input type="password" name="mdp" required>
                <input type="submit" name="valider" value="Se connecter">
                <nav class="compte">
                    <ul>
                        <li>Ouvrir un compte</li>
                        <li><a href="medecin.php">Médecin</a></li>
                        <li><a href="patient.php">Patient</a></li>
                    </ul>
                </nav>
                <div class="passe"><a href="#">mots de passe oublié?</a></div>
            </form>
        </section>
    </main>
    <footer>
        <p><em class="logo">sén médecin</em> copyright © 2023 - Tous droits réservés</p>
        <section class="foot">
            <div>
                <h5>A propos</h5>
                Bienvenue sur sén médecin, votre destination en ligne pour trouver des informations
                précieuses, des ressources utiles et des conseils pratiques dans le domaine de la santé et du
                bien-être. Notre mission est de fournir des contenus fiables et accessibles pour vous aider à
                prendre des décisions éclairées concernant votre santé. <a href="../fichierHTML/propos.html">plus</a>
            </div>
            <div>
                <h5>Contactez-nous</h5>
                Nous sommes là pour vous aider. N'hésitez pas à nous contacter pour toute question,
                préoccupation ou suggestion que vous pourriez avoir. Voici comment vous pouvez entrer en
                contact avec nous <a href="../fichierHTML/contact.html">plus</a>
            </div>
            <div>
                <h5>Nos services</h5>
                Chez sén médecin, nous sommes dévoués à améliorer votre santé et votre
                bien-être. Découvrez nos services personnalisés conçus pour répondre à vos besoins
                individuels <a href="../fichierHTML/services.html">plus</a>
            </div>
        </section>
    </footer>
</body>

</html>