<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../fichierCSS/style.css">
    <title>ajout</title>
</head>
<body>
    <header><h1>Ajout du patient</h1></header>

    <?php
        // Connexion à la base de données
        $mysqli = new mysqli('localhost', 'root', '', 'rendez-vous');

        // Vérifier la connexion
        if ($mysqli->connect_error) {
            die('Erreur de connexion à la base de données: ' . $mysqli->connect_error);
        }

        // Récupérer les données du formulaire
        @$nom = $_POST['nom'];
        @$prenom = $_POST['prenom'];
        @$email = $_POST['mail'];
        @$age = $_POST['age'];
        @$tel = $_POST['numtel'];
        @$adresse = $_POST['adresse'];
        @$sexe = $_POST['sexe'];

        // Requête SQL pour ajouter l'utilisateur
        $sql = "INSERT INTO patient (nom, prenom, age, tel, adresse, mail, sexe) VALUES ('$nom', '$prenom', '$age', '$tel', '$adresse', '$email', '$sexe')";

        if ($mysqli->query($sql) === TRUE) {
            header('location:gestPat.php');
        } else {
            echo "Erreur lors de l'ajout de l'utilisateur : " . $mysqli->error;
        }

        // Fermer la connexion à la base de données
        $mysqli->close();
    ?>
    
</body>
</html>