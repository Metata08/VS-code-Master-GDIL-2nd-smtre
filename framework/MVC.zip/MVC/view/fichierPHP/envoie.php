<?php

    // Récupération des données du formulaire
    @$user_id = $_POST['id'];
    @$message = $_POST['message'];

    // Enregistrement du message dans la base de données

    $mysqli = new mysqli('localhost', 'root', '', 'rendez-vous');

    if ($mysqli->connect_error) {
        die('Erreur de connexion à la base de données: ' . $mysqli->connect_error);
    }

    $sql = $mysqli->prepare("INSERT INTO messages (id_pat, contenu) VALUES (?, ?)");
    $sql->bind_param("is", $user_id, $message);

    if ($sql->execute()) {
        echo "Message enoyé !";
    } else {
        echo "Erreur lors de l'ajout de l'utilisateur : " . $sql->error;
    }

    // Fermer la connexion à la base de données
    $sql->close();
    // Fermer la connexion à la base de données
    $mysqli->close();

?>