<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sen Medecin</title>
    <link rel="stylesheet" href="../fichierCSS/visiteur.css">
</head>

<body>
    <header>
        <a href="visiteur.php">
            <h1>Sén médecin</h1>
        </a>
        <a href="../fichierHTML/navbar/propos.html">A propos</a>
        <a href="../fichierHTML/navbar/services.html">Services</a>
        <a href="../fichierHTML/navbar/contact.html">Contact</a>
    </header>
    <div class="navbar">
        <ul class="ulbar">
            <img src="../icones/menu.png">
            <li>
                <a href="visiteur.php"><img src="../icones/accueil.png">Accueil</a>
            </li>
            <li>
                <a href="list_medecin.php"><img src="../icones/medecin.png">Médecins</a>
            </li>
            <li>
                <a href="notification.php"><img src="../icones/notification.png">Notifications</a>
            </li>
            <li>
                <a href="listereservation.php"><img src="../icones/rendez-vous.png">Mes rendez-vous</a>
            </li>
            <li>

                <a href="historique.php"><img src="../icones/historique.png">Historique</a>
            </li>
        </ul>
    </div>
    <main>
        <div class="user">
            <?php 
            session_start(); 
            if(isset($_SESSION['nom']) && isset($_SESSION['prenom'])) {
                echo '<p>' . $_SESSION['prenom'] . ' ' . $_SESSION['nom'] . '</p>';
            } else {
                echo '<p>USER NAME</p>';
            }
            ?>
        </div>
        <script src="../fichierSCRIPT/visiteur.js"></script>


        <div class="container">
            <div class="column">
                <h2>La simplicité à portée de main</h2>
                <p>Chez <span id="site">senmedecin.sn</span>, nous comprenons que votre temps est précieux, et c'est
                    pourquoi nous avons créé un moyen pratique et rapide de prendre rendez-vous avec les meilleurs
                    médecins de votre région.</p>
            </div>
            <div class="column">
                <h2>Prendre rendez-vous en un clic</h2>
                <p>Notre interface conviviale vous permet de trouver facilement un médecin qui correspond à vos besoins,
                    de consulter leurs disponibilités en temps réel, et de réserver un créneau qui vous convient, le
                    tout en quelques clics.</p>
            </div>
            <div class="column">
                <h2>Votre santé, notre priorité</h2>
                <p>Et ce n'est pas tout. Nous vous offrons également la possibilité de recevoir des rappels de
                    rendez-vous, de consulter votre historique médical en un seul endroit, et même de bénéficier de
                    recommandations personnalisées pour améliorer votre bien-être.</p>
            </div>
        </div>
        <div style="text-align: center;" class="rv">
            <p>Prenez un rendez-vous maintenant avec votre:</p>
        </div>
        <div class="contener">
            <div class="med">
                <a href="calendrier-general.php">
                    <img src="../images/IMG_8515.jpg" alt="">
                    <div class="desc">Medecin general</div>
                </a>
            </div>
            <div class="med">
                <a href="calendrier-ophtalmo.php">
                    <img src="../images/IMG_8516.JPG" alt="image">
                    <div class="desc">Ophtalmologiste</div>
                </a>
            </div>
            <div class="med">
                <a href="calendrier-gyneco.php">
                    <img src="../images/IMG_8517.JPG" alt="image">
                    <div class="desc">Gynecologue</div>
                </a>
            </div>
            <div class="med">
                <a href="calendrier-dent.php">
                    <img src="../images/IMG_8518.JPG" alt="image">
                    <div class="desc">Dentiste</div>
                </a>
            </div>
            <div class="med">
                <a href="calendrier-neuro.php">
                    <img src="../images/IMG_8519.JPG" alt="image">
                    <div class="desc">Neurologue</div>
                </a>
            </div>
            <div class="med">
                <a href="calendrier-orthope.php">
                    <img src="../images/IMG_8515.jpg" alt="image">
                    <div class="desc">orthopediste</div>
                </a>
            </div>

        </div>

    </main>
    <footer>
        <p><em class="logo">sén médecin</em> copyright © 2023 - Tous droits réservés</p>
        <section class="foot">
            <div>
                <h5>A propos</h5>
                Bienvenue sur sén médecin, votre destination en ligne pour trouver des informations
                précieuses, des ressources utiles et des conseils pratiques dans le domaine de la santé et du
                bien-être. Notre mission est de fournir des contenus fiables et accessibles pour vous aider à
                prendre des décisions éclairées concernant votre santé. <a href="../fichierHTML/navbar/propos.html">plus</a>
            </div>
            <div>
                <h5>Contactez-nous</h5>
                Nous sommes là pour vous aider. N'hésitez pas à nous contacter pour toute question,
                préoccupation ou suggestion que vous pourriez avoir. Voici comment vous pouvez entrer en
                contact avec nous <a href="../fichierHTML/navbar/contact.html">plus</a>
            </div>
            <div>
                <h5>Nos services</h5>
                Chez sén médecin, nous sommes dévoués à améliorer votre santé et votre
                bien-être. Découvrez nos services personnalisés conçus pour répondre à vos besoins
                individuels <a href="../fichierHTML/navbar/services.html">plus</a>
            </div>
        </section>
    </footer>
</body>

</html>
