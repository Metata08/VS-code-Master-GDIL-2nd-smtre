<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../fichierCSS/style.css">
    <title>modification</title>
</head>
<body>
    <header>
        <a class="logo" href="../fichierHTML/admin-accueille.html">
            <h5>Sén médecin</h5>
        </a>
        <h1>MODIFICATION DU MEDECIN</h1>
    </header>
    <?php
        // Connexion à la base de données
        $mysqli = new mysqli('localhost', 'root', '', 'rendez-vous');

        // Vérifier la connexion
        if ($mysqli->connect_error) {
            die('Erreur de connexion à la base de données: ' . $mysqli->connect_error);
        }

        // Récupérer l'ID de l'utilisateur à modifier depuis l'URL
        $id = $_POST['id'];

        // Requête SQL pour récupérer les informations de l'utilisateur à modifier
        $sql = "SELECT * FROM medecin WHERE id = $id";
        $result = $mysqli->query($sql);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
        ?>

            <form class="maclasse" method="post" action="update.php">
                    <E-mail>Adresse électronique* :</E-mail>
                    <!--code php pour mettre les informations du médecin à modifier au chargement de la page
                    -->
                    <input type="text" name="mail" value="<?php echo $row['mail']; ?>">
                    <br>
                    <label for="nom">Nom* :</label>
                    <input type="text" name="nom" value="<?php echo $row['nom']; ?>">
                    <br>
                    <label for="prenom">Prénom* :</label>
                    <input type="text" name="prenom" value="<?php echo $row['prenom']; ?>">
                    <br>
                    <label for="age">Age* :</label>
                    <input type="number" name="age" value="<?php echo $row['age']; ?>">
                    <br>
                    <label for="numtel">Numéro de téléphone :</label>
                    <input type="tel" name="numtel" value="<?php echo $row['numero']; ?>">
                    <br>
                    <label for="adresse">Adresse* :</label>
                    <input type="text" name="adresse" value="<?php echo $row['adresse']; ?>">
                    <br>
                    <label for="specialite">Spécialité* :</label>
                    <input type="text" name="specialite" value="<?php echo $row['specialite']; ?>">
                    <br>
                    <div>
                        <label for="sexe">Sexe</label>
                        <input type="radio" name="sexe" value="Homme">Homme
                        <input type="radio" name="sexe" value="Femme">Femme
                    </div>
                    <br>
                    <div>
                        <button type="reset">Effacer</button>
                        <button type="submit" name="valider">Enregistrer</button>
                    </div>
            </form>

        <?php
        } else {
            echo "Utilisateur non trouvé.";
        }

        // Fermer la connexion à la base de données
        $mysqli->close();
    ?>
    
</body>