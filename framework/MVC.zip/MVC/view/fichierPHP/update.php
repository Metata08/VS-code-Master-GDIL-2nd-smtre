<?php

    // Connexion à la base de données
    $mysqli = new mysqli('localhost', 'root', '', 'rendez-vous');

    // Vérifier la connexion
    if ($mysqli->connect_error) {
        die('Erreur de connexion à la base de données: ' . $mysqli->connect_error);
    }

    // Récupérer les données du formulaire
    @$nom = $_POST['nom'];
    @$prenom = $_POST['prenom'];
    @$email = $_POST['mail'];
    @$age = $_POST['age'];
    @$tel = $_POST['numtel'];
    @$adresse = $_POST['adresse'];
    @$specialite = $_POST['specialite'];
    @$sexe = $_POST['sexe'];

    // Requête SQL préparée pour mettre à jour les informations de l'utilisateur ayant un ID spécifique 
    @$sql = "UPDATE medecin SET nom='$nom' ,prenom='$prenom' , age='$age' , numero='$tel' , adresse='$adresse' , specialite='$specialite' , mail='$email', sexe='$sexe' WHERE id=$id";

    // Exécuter la requête
    if ($mysqli->query($sql) === TRUE) {
        header('location:gestMed.php');
    } else {
        echo "Erreur lors de la mise à jour des informations de l'utilisateur : " . $mysqli->error;
    }

    // Fermer la connexion à la base de données
    $mysqli->close();

?>