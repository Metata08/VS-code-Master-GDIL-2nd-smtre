<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../fichierCSS/style.css">
    <title>suppression</title>
</head>
<body>
    <header>
        <a class="logo" href="../fichierHTML/admin-accueille.html">
            <h5>Sén médecin</h5>
        </a>
        <h1>SUPPRESSION DU PATIENT</h1>
    </header>

    <?php
        // Connexion à la base de données
        $mysqli = new mysqli('localhost', 'root', '', 'rendez-vous');

        // Vérifier la connexion
        if ($mysqli->connect_error) {
            die('Erreur de connexion à la base de données: ' . $mysqli->connect_error);
        }

        // Récupérer l'ID de l'utilisateur à supprimer
        $id = $_POST['id'];

        // Requête SQL pour supprimer un utilisateur
        $sql = "DELETE FROM patient WHERE id = $id";

        if ($mysqli->query($sql) === TRUE) {
            header('location:gestPat.php');
        } else {
            echo "Erreur lors de la suppression de l'utilisateur: " . $mysqli->error;
        }

        // Fermer la connexion à la base de données
        $mysqli->close();
    ?>
    
</body>
</html>