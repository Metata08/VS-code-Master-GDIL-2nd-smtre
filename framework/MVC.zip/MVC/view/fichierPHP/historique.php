<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Historique</title>
    <link rel="stylesheet" href="../fichierCSS/historique.css">
</head>
<body>
    <header>
        <a href="visiteur.php">
            <h1>Sén médecin</h1>
        </a>
        <a href="navbar/propos.html">A propos</a>
        <a href="navbar/services.html">Services</a>
        <a href="navbar/contact.html">Contact</a>
    </header>
    <div class="navbar">
        <ul class="ulbar">
            <img src="../icones/menu.png">
            <li>
                <a href="visiteur.php"><img src="../icones/accueil.png">Accueil</a>
            </li>
            <li>
                <a href="list_medecin.php"><img src="../icones/medecin.png">Médecins</a>
            </li>
            <li>
                <a href="notification.php"><img src="../icones/notification.png">Notifications</a>
            </li>
            <li>
                <a href="listereservation.php"><img src="../icones/rendez-vous.png">Mes rendez-vous</a>
            </li>
            <li>

                <a href="historique.php"><img src="../icones/historique.png">Historique</a>
            </li>
        </ul>
    </div>
    <main>
        <div class="user">
            <?php 
            session_start(); 
            if(isset($_SESSION['nom']) && isset($_SESSION['prenom'])) {
                echo '<p>' . $_SESSION['prenom'] . ' ' . $_SESSION['nom'] . '</p>';
            } else {
                echo '<p>USER NAME</p>';
            }
            ?>
        </div>
        
        <div class="bloc">
            <div class="contener">
                <table id="reservations">
                    <tr>
                        <div class="container">
                            <th>Medecin</th>
                            <th>Date</th>
                            <th>Heure</th>
                            <th>Action</th>
                        </div>
                    </tr>
                    <!-- Les lignes de réservation seront ajoutées dynamiquement ici -->
                </table>
            </div>
<script src="../fichierSCRIPT/historique.js"></script>
    </main>
    <footer>
        <p><em class="logo">sén médecin</em> copyright © 2023 - Tous droits réservés</p>
        <section class="foot">
            <div>
                <h5>A propos</h5>
                Bienvenue sur sén médecin, votre destination en ligne pour trouver des informations
                précieuses, des ressources utiles et des conseils pratiques dans le domaine de la santé et du
                bien-être. Notre mission est de fournir des contenus fiables et accessibles pour vous aider à
                prendre des décisions éclairées concernant votre santé. <a href="navbar/propos.html">plus</a>
            </div>
            <div>
                <h5>Contactez-nous</h5>
                Nous sommes là pour vous aider. N'hésitez pas à nous contacter pour toute question,
                préoccupation ou suggestion que vous pourriez avoir. Voici comment vous pouvez entrer en
                contact avec nous <a href="navbar/contact.html">plus</a>
            </div>
            <div>
                <h5>Nos services</h5>
                Chez sén médecin, nous sommes dévoués à améliorer votre santé et votre
                bien-être. Découvrez nos services personnalisés conçus pour répondre à vos besoins
                individuels <a href="navbar/services.html">plus</a>
            </div>
        </section>
    </footer>
</body>
</html>