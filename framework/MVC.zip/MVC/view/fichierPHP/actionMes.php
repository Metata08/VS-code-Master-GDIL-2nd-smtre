<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../fichierCSS/style.css">
    <title>suppression</title>
</head>
<body>
    <header>
        <a class="logo" href="../fichierHTML/admin-accueille.html">
            <h5>Sén médecin</h5>
        </a>
        <h1>SUPPRESSION.....</h1>
    </header>
    <div class="maclasse">
        <?php
            // Connexion à la base de données
            $mysqli = new mysqli('localhost', 'root', '', 'rendez-vous');

            // Vérifier la connexion
            if ($mysqli->connect_error) {
                die('Erreur de connexion à la base de données: ' . $mysqli->connect_error);
            }

            // Récupérer l'ID de l'utilisateur à supprimer
            @$id = $_POST['id'];

            // Requête SQL pour supprimer l'utilisateur (utilisation de requêtes préparées pour éviter les injections SQL)
            $sql = "DELETE FROM commentaires WHERE id = ?";
            $stmt = $mysqli->prepare($sql);

            // Vérifier la préparation de la requête
            if ($stmt) {
                // Lier les paramètres et exécuter la requête
                $stmt->bind_param("i", $id); // "i" indique un entier
                $stmt->execute();

                // Vérifier si la suppression a réussi
                if ($stmt->affected_rows > 0) {
                    header('location:commentaire.php');
                } else {
                    echo "Aucun utilisateur trouvé avec cet ID.";
                }

                // Fermer le statement
                $stmt->close();
            } else {
                echo "Erreur lors de la préparation de la requête : " . $connexion->error;
            }

            // Fermer la connexion à la base de données
            $mysqli->close();
            //Dans ce script, nous utilisons une requête préparée avec un paramètre ?pour l'ID de l'utilisateur. Nous lions ensuite cet ID à l'aide de bind_paramet exécutons la requête.Cette méthode est plus sécurisée car elle protège contre les attaques par injection SQL.

        ?>
    </div>
</body>
</html>