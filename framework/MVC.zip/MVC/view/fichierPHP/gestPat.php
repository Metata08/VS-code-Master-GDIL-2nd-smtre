<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patients</title>
    <link rel="stylesheet" href="../fichierCSS/style.css">
</head>
<body>
    <header>
        <a class="logo" href="../fichierHTML/admin-accueille.html">
            <h5>Sén médecin</h5>
        </a>
        <h1>GESTION DES PATIENTS</h1>
    </header>
    <div class="maclasse">
        <div class="pages">
            <a href="archive.php" class="ajout"><img src="../icones/archiver (1).png">Liste archive</a>
            <a href="archiver.php" class="ajout"><img src="../icones/mettre-a-jour.png">Archiver un patient</a>
            <a href="supprimerPat.php" class="ajout"><img src="../icones/supprimer.png">Supprimer un patient</a>
        </div>
        <tablez>
            <?php
                // Connexion à la base de données
                $mysqli = new mysqli('localhost', 'root', '', 'rendez-vous');

                // Vérifier la connexion
                if ($mysqli->connect_error) {
                    die('Erreur de connexion à la base de données: ' . $mysqli->connect_error);
                }

                // Requête SQL pour récupérer les utilisateurs
                $sql = "SELECT * FROM patient";
                $result = $mysqli->query($sql);

                // Vérifier s'il y a des résultats
                if ($result->num_rows > 0) {
                    // Afficher les utilisateurs sous forme de tableau
                    echo '<table border="0">';
                    echo '<tr><th>ID</th><th>Nom</th><th>Prenom</th><th>Age</th><th>Numéro</th><th>Adresse</th><th>Email</th><th>Sexe</th></tr>';
                    while($row = $result->fetch_assoc()) {
                        echo '<tr>';
                        echo '<td>' . $row['id'] . '</td>';
                        echo '<td>' . $row['nom'] . '</td>';
                        echo '<td>' . $row['prenom'] . '</td>';
                        echo '<td>' . $row['age'] . '</td>';
                        echo '<td>' . $row['tel'] . '</td>';
                        echo '<td>' . $row['adresse'] . '</td>';
                        echo '<td>' . $row['mail'] . '</td>';
                        echo '<td>' . $row['sexe'] . '</td>';
                        echo '</tr>';
                    }
                    echo '</table>';
                } else {
                    echo 'La liste des patients est vide !';
                }

                // Fermer la connexion à la base de données
                $mysqli->close();
            ?>
        </table>
    </div>
</body>
</html>