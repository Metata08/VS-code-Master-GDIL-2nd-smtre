<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Médecins</title>
    <link rel="stylesheet" href="../fichierCSS/style.css">
</head>
<body>
    <header>
        <a class="logo" href="../fichierHTML/admin-accueille.html">
            <h5>Sén médecin</h5>
        </a>
        <h1>GESTION DES MEDECINS</h1>
    </header>
    <div class="maclasse">
        <div class="pages">
            <a href="medecin.php" class="ajout"><img src="../icones/plus.png">Ajouter</a>
            <a href="modif.php" class="ajout"><img src="../icones/mettre-a-jour.png">Modifier</a>
            <a href="supprimerMed.php" class="ajout"><img src="../icones/supprimer.png">Supprimer</a>
        </div>
        <tablez>
            <?php
                // Connexion à la base de données
                $mysqli = new mysqli('localhost', 'root', '', 'rendez-vous');

                // Vérifier la connexion
                if ($mysqli->connect_error) {
                    die('Erreur de connexion à la base de données: ' . $mysqli->connect_error);
                }

                // Requête SQL pour récupérer les utilisateurs
                $sql = "SELECT * FROM medecin";
                $result = $mysqli->query($sql);

                // Vérifier s'il y a des résultats
                if ($result->num_rows > 0) {
                    // Afficher les utilisateurs sous forme de tableau
                    echo '<table border="0">';
                    echo '<tr><th>ID</th><th>Nom</th><th>Prenom</th><th>Age</th><th>Numéro</th><th>Adresse</th><th>Spécialite</th><th>Email</th><th>Sexe</th></tr>';
                    while($row = $result->fetch_assoc()) {
                        echo '<tr>';
                        echo '<td>' . $row['id'] . '</td>';
                        echo '<td>' . $row['nom'] . '</td>';
                        echo '<td>' . $row['prenom'] . '</td>';
                        echo '<td>' . $row['age'] . '</td>';
                        echo '<td>' . $row['numero'] . '</td>';
                        echo '<td>' . $row['adresse'] . '</td>';
                        echo '<td>' . $row['specialite'] . '</td>';
                        echo '<td>' . $row['mail'] . '</td>';
                        echo '<td>' . $row['sexe'] . '</td>';
                        echo '</tr>';
                    }
                    echo '</table>';
                } else {
                    echo 'La liste des médecins est vide !';
                }

                // Fermer la connexion à la base de données
                $mysqli->close();
            ?>
        </table>
    </div>
</body>
</html>