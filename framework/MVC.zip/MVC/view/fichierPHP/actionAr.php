<?php
    // Connexion à la base de données
    $mysqli = new mysqli('localhost', 'root', '', 'rendez-vous');

    // Vérifier la connexion
    if ($mysqli->connect_error) {
        die('Erreur de connexion à la base de données: ' . $mysqli->connect_error);
    }

    // Récupérer l'ID de l'utilisateur à supprimer
    @$id = $_POST['id'];

    // Requête SQL pour récupérer les informations de l'utilisateur
    $sql = "SELECT * FROM archive WHERE id = $id";

        $result = $mysqli->query($sql);
        if ($result->num_rows > 0) { 
        $row = $result->fetch_assoc();
            // Récupérer les données de l'utilisateur
            @$nom =  $row['nom'];
            @$prenom =  $row['prenom'];
            @$email =  $row['mail'];
            @$age =  $row['age'];
            @$tel =  $row['tel'];
            @$adresse =  $row['adresse'];
            @$sexe =  $row['sexe'];
        }
        if ($mysqli->query($sql) === TRUE) {
            echo "";
        } else {
            echo "Erreur lors de la récupération des données: " . $mysqli->error;
        }

        $sql = "DELETE FROM archive WHERE id = $id";

        if ($mysqli->query($sql) === TRUE) {
            echo"";
        } else {
            echo "Erreur lors de la suppression de l'utilisateur: " . $mysqli->error;
        }

    // Requête SQL pour rajouter l'utilisateur dans la liste des utilisateurs
    $sql = "INSERT INTO patient (nom, prenom, age, tel, adresse, mail, sexe) VALUES ('$nom', '$prenom', '$age', '$tel', '$adresse', '$email', '$sexe')";

    if ($mysqli->query($sql) === TRUE) {
        header('location:gestPat.php');
    } else {
        echo "Erreur lors de l'ajout de l'utilisateur : " . $mysqli->error;
    }

    // Fermer la connexion à la base de données
    $mysqli->close();

?>