<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../fichierCSS/style.css">
    <title>archive</title>
</head>
<body>
    <header>
        <a class="logo" href="../fichierHTML/admin-accueille.html">
            <h5>Sén médecin</h5>
        </a>
        <h1>ARCHIVER UN PATIENT</h1>
    </header>
    <form class="maclasse" action="listeAr.php" method="post">
        ID du patient à archiver:
        <input type="text" name="id"><br>
        <button type="submit">Archiver</button>
</form>
</body>
</html>