// Fonction pour ajouter une notification à la liste
function addNotification(message) {
    const notificationList = document.getElementById('notificationList');
    const listItem = document.createElement('li');
    listItem.textContent = message;
    notificationList.appendChild(listItem);
}

// Exemple d'ajout d'une notification 
addNotification("Rappel : Rendez-vous aujourdhui à 15h à ngalel.");
addNotification("Nouveau: Rendez-vous lundi 23 Octobre 2023 à Sanar , Saint-louis.");