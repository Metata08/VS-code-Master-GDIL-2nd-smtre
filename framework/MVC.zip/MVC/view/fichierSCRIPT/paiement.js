document.addEventListener('DOMContentLoaded', function () {
    var stripe = Stripe('VOTRE_CLÉ_PUBLIQUE_STRIPE');
    var elements = stripe.elements();
    var cardElement = elements.create('card');

    cardElement.mount('#card-element');

    var form = document.getElementById('payment-form');

    form.addEventListener('submit', function (event) {
        event.preventDefault();

        stripe.createToken(cardElement).then(function (result) {
            if (result.error) {
                var errorElement = document.getElementById('card-errors');
                errorElement.textContent = result.error.message;
            } else {
                // Envoyez le token au serveur pour le traitement ultérieur
                fetch('/charge', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ token: result.token.id, amount: form.amount.value }),
                })
                .then(response => response.json())
                .then(data => {
                    console.log(data);
                    alert('Paiement réussi!');
                })
                .catch(error => {
                    console.error('Erreur lors du paiement:', error);
                    alert('Erreur lors du paiement. Veuillez réessayer.');
                });
            }
        });
    });
});
