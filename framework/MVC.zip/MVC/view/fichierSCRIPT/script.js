// changement de classe du header
window.addEventListener("scroll", function() {
    var header = document.querySelector(".sticky-header");
    header.classList.toggle("sticky", window.scrollY > 0);
    scrollTimeout = this.setTimeout(function() {
        if (window.scrollY > 0> 0) {
            header.classList.add("defiler");
        } else {
            header.classList.remove("defiler");
        }
    }, 300); // Délai avant changement en millisecondes
});