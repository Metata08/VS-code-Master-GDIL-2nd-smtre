const reviews = [];

function displayReviews() {
    const reviewsContainer = document.getElementById("reviews");
    reviewsContainer.innerHTML = "";

    reviews.forEach(review => {
        const reviewDiv = document.createElement("div");
        reviewDiv.classList.add("review");
        reviewDiv.innerHTML = `<strong>${review.username} :</strong> ${review.text} ,  NOTE: <strong>${review.note}</strong> <br><br><br>`;
        reviewsContainer.appendChild(reviewDiv);
    });
}

document.getElementById("leaveReviewBtn").addEventListener("click", () => {
    const reviewForm = document.getElementById("reviewForm");
    reviewForm.style.display = "block";
});

document.getElementById("submitReview").addEventListener("click", () => {
    const username = document.getElementById("username").value;
    const reviewText = document.getElementById("reviewText").value;
    const note= document.getElementById("note").value;
    if (username && reviewText && note) {
        const newReview = {
            username: username,
            text: reviewText,
            note : note
        };

        reviews.push(newReview);
        displayReviews();

        // Réinitialise le formulaire
        document.getElementById("username").value = "";
        document.getElementById("reviewText").value = "";
        document.getElementById("note").value="";
        document.getElementById("reviewForm").style.display = "none";
    }
});

// Exemple de données d'avis pré-remplis (simulées)
const initialReviews = [
    { username: "Amadou", text: "Excellent service médical !" ,note:"3"},
    { username: "Sokhna", text: "Le médecin était très attentionné.",note:"4" }
];

reviews.push(...initialReviews);
displayReviews();
