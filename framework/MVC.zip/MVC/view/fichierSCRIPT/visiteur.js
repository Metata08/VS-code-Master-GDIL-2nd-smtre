document.getElementById("toggle-menu").addEventListener("click", function () {
  var menu = document.querySelector(".menu");
  var content = document.querySelector(".content");

  menu.classList.toggle("menu-open");
  content.classList.toggle("menu-open");
});
