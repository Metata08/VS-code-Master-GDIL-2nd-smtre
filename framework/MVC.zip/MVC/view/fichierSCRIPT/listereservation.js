const reservationsData = [
    {  Medecin: 'Dr Niang' ,date: '2023-10-10', Heure:"10h00"},
    {  Medecin: 'Dr Loum',date: '2023-11-25', Heure:'8h00'},
    {  Medecin: 'Dr Ndiaye',date: '2023-11-03', Heure:'12h00'},

    // Ajoutez d'autres réservations ici
];

const reservationsTable = document.getElementById('reservations');

// Fonction pour afficher les réservations dans le tableau
function displayReservations() {
    reservationsTable.innerHTML = '<tr><th>Medecin</th><th>Date</th><th>Heure</th><th>Action</th></tr>';
    
    for (const reservation of reservationsData) {
        const row = reservationsTable.insertRow();
        const MedecinCell = row.insertCell(0);
        const dateCell = row.insertCell(1);
        const HeureCell = row.insertCell(2);
        const actionCell = row.insertCell(3);


        MedecinCell.textContent = reservation.Medecin;
        dateCell.textContent = reservation.date;
        HeureCell.textContent = reservation.Heure;


        // Ajoutez des boutons pour modifier et annuler
        const modifyBtn = createButton1('Modifier', () => modifyReservation(reservation));
        const cancelBtn = createButton2('Annuler', () => cancelReservation(reservation));

        actionCell.appendChild(modifyBtn);
        actionCell.appendChild(cancelBtn);
    }
}

// Fonction pour créer un bouton avec un gestionnaire d'événements
function createButton1(text, onClick) {
    const button = document.createElement('button');
    button.textContent = text;
    button.className = 'btn';
    button.addEventListener('click', onClick);
    return button;
}
function createButton2(text, onClick) {
    const button = document.createElement('button');
    button.textContent = text;
    button.className = 'btn-cancel';
    button.addEventListener('click', onClick);
    return button;
}


// Fonction pour modifier une réservation
function modifyReservation(reservation) {
    // Mettez en œuvre la logique de modification ici
    console.log('Modifier la réservation:', reservation);
}

// Fonction pour annuler une réservation
function cancelReservation(reservation) {
    // Mettez en œuvre la logique d'annulation ici
    console.log('Annuler la réservation:', reservation);
}

// Afficher les réservations initiales
displayReservations();