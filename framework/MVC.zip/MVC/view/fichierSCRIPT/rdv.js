// fonction pour le tri selon le nom de l'utilisateur ...
function tri_Tab(columnIndex) {
    var table, rows, switching, i, x, y, shouldSwitch;
    table = document.getElementById("monTable");
    switching = true;
    while (switching) {
        switching = false;
        rows = table.rows;
        for (i = 1; i < (rows.length - 1); i++) {
            shouldSwitch = false;
            x = rows[i].getElementsByTagName("td")[columnIndex];
            y = rows[i + 1].getElementsByTagName("td")[columnIndex];
            if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
                shouldSwitch = true;
                break;
            }
        }
        if (shouldSwitch) {
            rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
            switching = true;
        }
    }
}

  // Fonction pour gérer la recherche en temps réel
    document.getElementById("entree_rech").addEventListener("keyup", function() {
    var input, filter, table, tr, td, i, j, txtValue;
    input = document.getElementById("entree_rech");
    filter = input.value.toUpperCase();
    table = document.getElementById("monTable");
    tr = table.getElementsByTagName("tr");

    // Parcourez toutes les lignes du tableau, sauf la première (en-tête)
    for (i = 1; i < tr.length; i++) {
        tr[i].style.display = "none"; // Masquez initialement toutes les lignes

        // Parcourez toutes les cellules de la ligne actuelle
        for (j = 0; j < tr[i].getElementsByTagName("td").length; j++) {
            td = tr[i].getElementsByTagName("td")[j];
            if (td) {
                txtValue = td.textContent || td.innerText;
                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    tr[i].style.display = ""; // Affichez la ligne si elle correspond à la recherche
                    break; // Sortez de la boucle interne pour ne pas répéter l'affichage
                }
            }
        }
    }
});

/// Récupérez tous les boutons avec la classe "valide" et "non-valide"
var boutonsValides = document.querySelectorAll(".valide");
// var boutonsNonValides = document.querySelectorAll(".non-valide");

// Ajoutez un gestionnaire d'événements pour les boutons "Valide"
boutonsValides.forEach(function(bouton) {
    bouton.addEventListener("click", function() {
        // Logique de validation ici (ex : si le bouton est valide, basculez-le à non-valide)
        if (bouton.classList.contains("valide")) {
            bouton.classList.remove("valide");
            bouton.classList.add("non-valide");
        } else {
            bouton.classList.remove("non-valide");
            bouton.classList.add("valide");
        }
    });
});

// // Ajoutez un gestionnaire d'événements pour les boutons "Non Valide"
// boutonsNonValides.forEach(function(bouton) {
//     bouton.addEventListener("click", function() {
//         // Logique de validation ici (ex : si le bouton est non-valide, basculez-le à valide)
//         if (bouton.classList.contains("non-valide")) {
//             bouton.classList.remove("non-valide");
//             bouton.classList.add("valide");
//         } else {
//             bouton.classList.remove("valide");
//             bouton.classList.add("non-valide");
//         }
//     });
// });

