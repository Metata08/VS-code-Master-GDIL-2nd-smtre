document.addEventListener("DOMContentLoaded", function () {
    const specialiteInput = document.getElementById("specialite");
    const dateInput = document.getElementById("date");
    const heureSelect = document.getElementById("heure");
    const doctorsTable = document.getElementById("med-table");
    // Liste des heures (8:00  - 18:00 )
    const hours = ["8:00 ", "10:00 ", "12:00 ", "14:00 ", "16:00 ", "18:00 "];
    hours.forEach((hour) => {
        const option = document.createElement("option");
        option.value = hour;
        option.textContent = hour;
        heureSelect.appendChild(option);
    });

    // Écouteurs d'événements pour les champs de spécialité, jour, mois, année et heure
    specialiteInput.addEventListener("change", generateDoctorsTable);
   
    dateInput.addEventListener("change", generateDoctorsTable);

    heureSelect.addEventListener("change", generateDoctorsTable);

    // Génère le tableau des médecins et de leur calendrier de disponibilité
    function generateDoctorsTable() {
        // Supprime le contenu existant du tableau
        doctorsTable.innerHTML = "";

        const specialite = specialiteInput.value;
        // const jour = jourSelect.value;
        // const mois = moisSelect.value;
        const date = dateInput.value;
        // const annee = anneeSelect.value;
        const heure = heureSelect.value;

        // Vous devrez ajouter ici la logique pour récupérer les médecins et leur disponibilité
        // à partir d'une source de données, comme une API ou une base de données.

        // Exemple de génération de données fictives (à remplacer par la logique réelle) :
        const medecins = [
            { nom: "Dr. Diop", disponibilite: ["8:00 ", "10:00 ", "12:00 ", "14:00 ", "16:00 ", "18:00","20:00"],note:"5/5",choix:"button"},
            { nom: "Dr. Ndiaye", disponibilite: ["10:00 ", "12:00 ", "14:00 ", "16:00 ", "18:00","20:00"],note:"4/5" ,choix:"button"},
            { nom: "Dr. Gueye", disponibilite: ["8:00 ", "10:00 ", "12:00 ", "14:00 ", "16:00 ", "18:00","20:00"],note:"3/5",choix:"button"}

            // Ajoutez d'autres médecins et leur disponibilité ici
        ];

        // Crée la ligne d'en-tête du tableau
        const tableHeaderRow = document.createElement("tr");
        tableHeaderRow.innerHTML = "<th>Médecin</th><th>Disponibilité</th><th>Note</th><th>Choisir</th>";
        doctorsTable.appendChild(tableHeaderRow);

        // Crée une ligne pour chaque médecin avec sa disponibilité
        medecins.forEach((medecin) => {
            const doctorRow = document.createElement("tr");
            doctorRow.innerHTML = `<td>${medecin.nom}</td><td>${medecin.disponibilite.join("    -    ")}</td><td>${medecin.note}</td><td><input type="checkbox"> OK<br>
            </td>`;
            doctorsTable.appendChild(doctorRow);
        });
    }

    // Appel initial pour générer le tableau en fonction des valeurs par défaut
    generateDoctorsTable();
});




// 
// 
// 



document.addEventListener('DOMContentLoaded', function () {
    const bookingForm = document.getElementById('booking-form');
    const summaryDiv = document.getElementById('summary');

    bookingForm.addEventListener('submit', function (e) {
        e.preventDefault();

        // Récupérer les données du formulaire
        const appointmentspecialite = document.getElementById('specialite').value;
        const appointmentDate = document.getElementById('date').value;
        const appointmentTime = document.getElementById('heure').value;

        // Créer un résumé au format HTML
        const summaryHTML = `
        <h2 style="text-decoration:underline;">Vous venez de faire une reservation:</h2>
        <p><strong>Specialite du medecin:</strong> ${appointmentspecialite}</p>
        <p><strong>Date du Rendez-vous:</strong> ${appointmentDate}</p>
        <p><strong>Heure du Rendez-vous:</strong> ${appointmentTime}</p>
        <p> <h3>Votre reservation est prise en compte !</h3> </p>
        
        </div>
        `;

        // Afficher le résumé dans la zone prévue
        summaryDiv.innerHTML = summaryHTML;

        // Réinitialiser le formulaire
        bookingForm.reset();
    });
});

// Fonction pour initialiser la carte
function initMap() {
    // Créez une carte Google Maps centrée sur une position par défaut
    var map = new google.maps.Map(document.getElementById('map'), {
        center: { lat: 14.7423232, lng: -17.4424064 }, // Coordonnées par défaut
        zoom: 12 // Niveau de zoom
    });

    // Demandez la géolocalisation de l'utilisateur
    if ("geolocation" in navigator) {
        navigator.geolocation.getCurrentPosition(function (position) {
            // Obtenez les coordonnées de l'utilisateur
            var userLatLng = {
                lat: position.coords.latitude,
                lng: position.coords.longitude
            };

            // dimensin de l'image des marqueurs 
            var image = {
                url: "../image/icons/lieu.png", // Remplacez par le chemin de votre icône personnalisée
                scaledSize: new google.maps.Size(60, 60)
            };// Remplacez les dimensions par la taille souhaitée
            // Créez un marqueur pour la position de l'utilisateur
            var userMarker = new google.maps.Marker({
                position: userLatLng,
                map: map,
                title: 'Ma position',
                icon: image,
            });

            // Centrez la carte sur la position de l'utilisateur
            map.setCenter(userLatLng);
        });
    } else {
        // Gestion du cas où la géolocalisation n'est pas prise en charge
        alert('La géolocalisation n\'est pas prise en charge par votre navigateur.');
    }

    const prestataires = [
        { nom: "Dr Ndiaye", latitude: 16.0655071, longitude: -16.421010 },
        { nom: "Dr Diop", latitude: 16.0655071, longitude: -16.422030 },
        // Ajoutez d'autres prestataires ici
    ];

    // Affichage des marqueurs pour les prestataires
    // prestataires.forEach((prestataire) => {
    //     const marker = new google.maps.Marker({
    //         position: { lat: prestataire.latitude, lng: prestataire.longitude },
    //         map: map,
    //         title: prestataire.nom,
    //     });

    // Vous pouvez également personnaliser les marqueurs ou ajouter des informations supplémentaires

    var doc_image = {
                url: "../image/icons/docteur.png", // Remplacez par le chemin de votre icône personnalisée
                scaledSize: new google.maps.Size(60, 60)
            };
    // Personnalisation des marqueurs des prestataires
    prestataires.forEach((prestataire) => {
        var marker = new google.maps.Marker({
            position: { lat: prestataire.latitude, lng: prestataire.longitude },
            map: map,
            title: prestataire.nom,
            icon: doc_image,// Remplacez "lien-vers-votre-icone.png" par le chemin de votre icône personnalisée
            label: {
                text: prestataire.nom, // Étiquette personnalisée
                color: "white", // Couleur de l'étiquette
            },
        });

        // Personnalisation de l'info-bulle
        var infoWindow = new google.maps.InfoWindow({
            content: "<h3>" + prestataire.nom + "</h3>" + "<p>Adresse : " + prestataire.adresse + "</p>",
        });

        marker.addListener("click", function () {
            infoWindow.open(map, marker);
        });
    });


}

