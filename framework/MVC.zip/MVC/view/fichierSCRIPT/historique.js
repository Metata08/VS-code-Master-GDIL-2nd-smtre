const reservationsData = [
    {  Medecin: 'Dr Niang' ,date: '2023-10-10', Heure:"10h00",statut:"OK"},
    {  Medecin: 'Dr Loum',date: '2023-11-25', Heure:'8h00',statut:"OK"},
    {  Medecin: 'Dr Ndiaye',date: '2023-11-03', Heure:'12h00',statut:"OK"},

    // Ajoutez d'autres réservations ici
];

const reservationsTable = document.getElementById('reservations');

// Fonction pour afficher les réservations dans le tableau
function displayReservations() {
    reservationsTable.innerHTML = '<tr><th>Medecin</th><th>Date</th><th>Heure</th><th>statut</th></tr>';
    
    for (const reservation of reservationsData) {
        const row = reservationsTable.insertRow();
        const MedecinCell = row.insertCell(0);
        const dateCell = row.insertCell(1);
        const HeureCell = row.insertCell(2);
        const statutCell = row.insertCell(3);


        MedecinCell.textContent = reservation.Medecin;
        dateCell.textContent = reservation.date;
        HeureCell.textContent = reservation.Heure;
        statutCell.textContent= reservation.statut;

}}




// Afficher les réservations initiales
displayReservations();