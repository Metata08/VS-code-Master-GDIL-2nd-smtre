-- Active: 1708642145280@@127.0.0.1@5432@visieurs
CREATE TABLE visiteurs(
    adr_mail VARCHAR(100) PRIMARY KEY,
    mdp VARCHAR(50) UNIQUE,
    nom VARCHAR(30),
    prenom VARCHAR(30),
    age  INTEGER,
    sexe VARCHAR(1),
    telephone VARCHAR(9),
    adresse VARCHAR(100)
);


INSERT INTO visiteurs(adr_mail,mdp,nom,prenom,age,sexe,telephone,adresse)
VALUES('user','123','monnom','monprenom',1,m,771234567,'ugb')