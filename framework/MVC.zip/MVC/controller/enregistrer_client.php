<?php

if (!isset($_POST['mail']) || !isset($_POST['mdp']) ||  !isset($_POST['nom']) || !isset($_POST['prenom']) || !isset($_POST['age']) ||  !isset($_POST['adresse']) || !isset($_POST['sexe'])) {
    header("location:../view/fichierPHP/patient.php");
    exit(); // Sortie après la redirection
}

$mail = $_POST['mail'];
$mdp = $_POST['mdp'];
$nom = $_POST['nom'];
$prenom = $_POST['prenom'];
$age = $_POST['age'];
$adresse = $_POST['adresse'];
$sexe = $_POST['sexe'];
$tel = $_POST['numTel']; // En supposant que numTel est le nom du champ de saisie du numéro de téléphone

$serveur = "localhost";
$login = "root";
$baseDeDonnees = "visiteur";
$motDePasse = "";

try {
    $connexion = new PDO("mysql:host=$serveur;dbname=$baseDeDonnees", $login, $motDePasse);
    $requete = $connexion->prepare("INSERT INTO visiteurs (adr_mail, mdp, nom, prenom, age, sexe, telephone, adresse) VALUES (:adr_mail, :mdp, :nom, :prenom, :age, :sexe, :telephone, :adresse)");

    $requete->bindValue(':adr_mail', $mail);
    $requete->bindValue(':mdp', $mdp);
    $requete->bindValue(':nom', $nom);
    $requete->bindValue(':prenom', $prenom); // Correction de la liaison
    $requete->bindValue(':age', $age);
    $requete->bindValue(':sexe', $sexe);
    $requete->bindValue(':telephone', $tel); // Correction de la liaison
    $requete->bindValue(':adresse', $adresse);
    $requete->execute();

    header('location:../view/fichierPHP/connect.php');
    exit(); // Sortie après la redirection

} catch (PDOException $e) {
    header("location:../view/fichierPHP/patient.php");
    die('Erreur de connexion à la base de données: ' . $e->getMessage());

}
?>
