<?php

$server="localhost";
$login="root";
$database="visiteur";
$passwordl="";


try{
$connection=new PDO("mysql:host=$server;dbname=$database",$login,$passwordl);
}
catch(PDOException $e)
{
    die('Erreur de connexion à la base de données: '. $e->getMessage());
}

?>