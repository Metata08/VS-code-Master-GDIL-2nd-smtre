<?php
session_start(); // Démarrer la session

if(!isset($_POST['mail']) || !isset($_POST['mdp'])) {
    header('location:../view/fichierPHP/connect.php');
    exit; // Arrêter l'exécution du script
}

include('connectBd.php');

$mail = $_POST['mail'];
$mdp = $_POST['mdp'];

// Utilisation de requêtes préparées pour éviter les injections SQL
$req = $connection->prepare("SELECT * FROM visiteurs WHERE adr_mail = :mail AND mdp = :mdp");
$req->execute(array('mail' => $mail, 'mdp' => $mdp));

$resultat = $req->fetchAll(PDO::FETCH_ASSOC);

include('deconnectBd.php');

if(count($resultat) == 0) {
    header('location:../view/fichierPHP/connect.php');
    exit; // Arrêter l'exécution du script
} else {
    // Récupérer le nom et le prénom du visiteur
    $nom = $resultat[0]['nom']; // Modifier si la structure de la table est différente
    $prenom = $resultat[0]['prenom']; // Modifier si la structure de la table est différente
    
    // Stocker le nom et le prénom dans la session
    $_SESSION['nom'] = $nom;
    $_SESSION['prenom'] = $prenom;

    // Rediriger vers la page du visiteur
    header('location:../view/fichierPHP/visiteur.php');
    exit; // Arrêter l'exécution du script
}
?>
