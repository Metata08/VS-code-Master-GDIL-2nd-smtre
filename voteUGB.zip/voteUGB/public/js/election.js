if (session('success')) {
    var successModal = new bootstrap.Modal(document.getElementById('successModal'));
    successModal.show();
}

