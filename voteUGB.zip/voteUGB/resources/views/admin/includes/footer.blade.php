<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Admin UGBvote</b>
    </div>
    <strong> &copy; 2025 UGB-Vote</strong>
</footer>