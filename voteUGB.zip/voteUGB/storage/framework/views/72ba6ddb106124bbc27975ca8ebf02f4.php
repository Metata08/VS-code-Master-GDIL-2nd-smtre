<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Audiowide&family=Tienne&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/inscription.css')); ?>">

    <script src="<?php echo e(asset('jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('jquery/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('jquery/form-validation.js')); ?>"></script>

    <title>Vote UGB - Inscription</title>
</head>
<body>
    <header class="container-fluid">
        <div class="logo">
            <a href="<?php echo e(url('/')); ?>"><img src="images/logo.png" alt="Logo de l'Université Gaston Berger" loading="lazy"></a>
        </div>
    </header>
    <div class="header-container">
        <img src="images/header.jpg" alt="Étudiants de l'UGB" loading="lazy">
        <h1 class="page-title">Élection du représentant des étudiants</h1>
    </div>
    <main class="row">
        <div class="col-md-4 col-12 urne">
            <img src="images/urne.png" alt="" srcset="">
        </div>
        <div class="col-md-8 col-12 conteneur-form">
            <h1 class="text">Inscrivez-Vous !</h1>
            <form action="<?php echo e(route('ajouterEtudiants')); ?>" id="inscriptionForm" method="post" novalidate name="formulaire">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="form-group mb-3 position-relative col">
                        <label for="prenom" class="form-label position-absolute bg-white px-2">
                            Entrez votre prénom
                        </label>
                        <input type="text" name="prenom" class="form-control" id="prenom" value="<?php echo e(old('prenom')); ?>" required>
                        <?php $__errorArgs = ['prenom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group mb-3 position-relative col">
                        <label for="nom" class="form-label position-absolute bg-white px-2">
                            Entrez votre nom
                        </label>
                        <input type="text" name="nom" id="nom" class="form-control" value="<?php echo e(old('nom')); ?>" required>
                        <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="form-group mb-3 position-relative">
                    <label for="email" class="form-label position-absolute bg-white px-2">
                        Entrez votre e-mail
                    </label>
                    <input type="email" name="email" id="email" class="form-control" value="<?php echo e(old('email')); ?>" required>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
                <div class="form-group mb-3 position-relative">
                    <label for="ufr" class="form-label position-absolute bg-white px-2">
                        Sélectionner votre ufr
                    </label>
                    <select name="ufr" id="ufr" class="form-control">
                        <option value="sciences">Sciences et Technologies</option>
                        <option value="lettres">Lettres et Sciences Humaines</option>
                        <option value="droit">Droit</option>
                        <option value="economie">Économie et Gestion</option>   
                    </select>
                </div>
                <div class="form-group mb-3 position-relative">
                    <label for="password" class="form-label position-absolute bg-white px-2">
                        Entrer votre password
                    </label>
                    <input type="password" name="password" id="password" class="form-control" required>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group mb-3 position-relative">
                    <label for="confpassword" class="form-label position-absolute bg-white px-2">
                        Confirmer votre password
                    </label>
                    <input type="password" name="password_confirmation" id="confpassword" class="form-control" required>
                </div>
                <div class="row">
                    <div class="col">
                        <button type="submit" class="btn text-white valider">Valider</button>
                    </div>
                    <div class="col">
                        <button type="reset" class="btn text-white annuler bg-danger">Annuler</button>
                    </div>
                </div>
                <div class="mt-3">
                    <p style="font-family:Inter; font-weigth: bold;">Avez-vous déjà un compte? <a href="#">Connectez-vous</a></p>
                </div>
            </form>
        </div>
    </main>
    <footer class="row">
        <div class="col col-md-4">reseaux</div>
        <div class="col col-md-4">@ 2025 UGBVote</div>
        <div class="col col-md-4">Liens utiles</div>
    </footer>
    
</body>
</html><?php /**PATH C:\Users\FICKOU\Desktop\projet_Dev_WEB_23-24\voteUGB\resources\views/inscription.blade.php ENDPATH**/ ?>