<?php echo $__env->make('admin.includes.session', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.includes.slugify', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.includes.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <?php echo $__env->make('admin.includes.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <?php echo $__env->make('admin.includes.menubar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Candidats
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo e(route('dashboardAdmin')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Candidats</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
     
    </section>
  </div>
  
  <?php echo $__env->make('admin.includes.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</div>
<!-- ./wrapper -->
</body>
</html><?php /**PATH C:\Users\FICKOU\Desktop\projet_Dev_WEB_23-24\voteUGB\resources\views/admin/candidats.blade.php ENDPATH**/ ?>