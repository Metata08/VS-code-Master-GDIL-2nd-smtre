<?php echo $__env->make('admin.includes.session', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.includes.slugify', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.includes.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<body class="hold-transition skin-blue sidebar-mini">
  <div class="wrapper">

    <?php echo $__env->make('admin.includes.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('admin.includes.menubar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <h1>
        Tableau de bord
        </h1>
        <ol class="breadcrumb">
          <li><a href="<?php echo e(route('dashboardAdmin')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
          <li class="active">Tableau de bord</li>
        </ol>
      </section>

      <!-- Main content -->
      <section class="content">
        <!-- Small boxes (Stat box) -->
        <div class="row">
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-aqua">
              <div class="inner">
                <h3><?php echo e($nombreDePostes); ?></h3>
                <p>Nombre de postes</p>
              </div>
              <div class="icon">
                <i class="fa fa-tasks"></i>
              </div>
              <a href="#" class="small-box-footer">Plus d'infos <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-green">
              <div class="inner">
                <h3><?php echo e($nombreDeCandidats); ?></h3>
                <p>Nombre de listes</p>
              </div>
              <div class="icon">
                <i class="fa fa-black-tie"></i>
              </div>
              <a href="#" class="small-box-footer">Plus d'infos <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-yellow">
              <div class="inner">
                <h3><?php echo e($nombreTotalElecteurs); ?></h3>
                <p>Nombre total d'électeurs</p>
              </div>
              <div class="icon">
                <i class="fa fa-users"></i>
              </div>
              <a href="#" class="small-box-footer">Plus d'infos <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-red">
              <div class="inner">
                <h3><?php echo e($nombreElecteursVotants); ?></h3>
                <p>Les électeurs ont voté</p>
              </div>
              <div class="icon">
                <i class="fa fa-edit"></i>
              </div>
              <a href="#" class="small-box-footer">Plus d'infos <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
        </div>

        <div class="row">
          <div class="col-xs-12">
            <h3>Décompte des votes
              <span class="pull-right">
                <a href="#" class="btn btn-success btn-sm btn-flat"><span class="glyphicon glyphicon-print"></span> Imprimer</a>
              </span>
            </h3>
          </div>
        </div>


        <div class="container my-4">
          <div id="chart-container">
            <canvas id="groupedBarChart"></canvas>
          </div>
        </div>
      </section>


    </div>
    <!-- Inclusions JS -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>


    <!-- Passage de la variable positions via JSON -->
    <script>
      var positions = JSON.parse('<?php echo json_encode($positions); ?>');
    </script>

<script>
  var dataGrouped = positions;

  var positions = [...new Set(dataGrouped.map(item => item.position))]; // ["sat", "dakar"]
  var candidats = [...new Set(dataGrouped.map(item => item.candidat))]; // ["crak", "convergence"]

  var datasets = candidats.map(candidat => ({
    label: candidat,
    data: positions.map(position =>
      (dataGrouped.find(d => d.candidat === candidat && d.position === position) || {}).nombre_de_votes || 0
    ),
    backgroundColor: 'rgba(' + Math.floor(Math.random() * 255) + ',' +
                              Math.floor(Math.random() * 255) + ',' +
                              Math.floor(Math.random() * 255) + ', 0.7)',
    borderWidth: 1
  }));

  var ctx = document.getElementById('groupedBarChart').getContext('2d');
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: positions,
      datasets: datasets
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: { y: { beginAtZero: true } }
    }
  });
</script>

    <?php echo $__env->make('admin.includes.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


    <?php echo $__env->make('admin.includes.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  </div>

</body>

</html><?php /**PATH C:\Users\FICKOU\Desktop\projet_Dev_WEB_23-24\voteUGB\resources\views/admin/home.blade.php ENDPATH**/ ?>