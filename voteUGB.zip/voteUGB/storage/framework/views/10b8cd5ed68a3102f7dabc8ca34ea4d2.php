<?php echo $__env->make('admin.includes.session', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.includes.slugify', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.includes.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<link rel="stylesheet" href="<?php echo e(asset('fontawesome-free-6.5.2-web/css/all.css')); ?>">
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <?php echo $__env->make('admin.includes.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <?php echo $__env->make('admin.includes.menubar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

 
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Electeurs
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo e(route('dashboardAdmin')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Electeurs</li>
      </ol>
    </section>


    <!-- Main content -->
    <section class="content">
    <?php if(isset($etudiants) && $etudiants->count() > 0): ?>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Prénom</th>
                <th scope="col">Nom</th>
                <th scope="col">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $etudiants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etudiant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($etudiant->id); ?></td>
                    <td><?php echo e($etudiant->prenom); ?></td>
                    <td><?php echo e($etudiant->nom); ?></td>
                    <td>
                        <!-- Bouton de suppression -->
                        <form action="<?php echo e(route('deleteElecteur', $etudiant->id_etudiant)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?> <!-- Utiliser DELETE au lieu de POST -->
                            <button type="submit" class="btn btn-danger" onclick="return confirm('Voulez-vous vraiment supprimer cet électeur ?')">
                                <i class="fa fa-trash"></i>
                            </button>
                        </form>

                        <!-- Bouton d'édition -->
                        <a href="#" class="btn btn-secondary">
                            <i class="fa fa-pencil"></i>
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php else: ?>
    <p class="text-center">Aucun électeur trouvé.</p>
<?php endif; ?>
    </section>
  </div>
  
  <?php echo $__env->make('admin.includes.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</div>
<?php echo $__env->make('admin.includes.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>
</html>
<?php /**PATH C:\Users\FICKOU\Desktop\projet_Dev_WEB_23-24\voteUGB\resources\views/admin/electeurs.blade.php ENDPATH**/ ?>