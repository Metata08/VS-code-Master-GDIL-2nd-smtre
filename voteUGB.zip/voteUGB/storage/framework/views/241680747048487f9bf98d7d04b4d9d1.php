<?php echo $__env->make('admin.includes.session', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.includes.slugify', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.includes.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <?php echo $__env->make('admin.includes.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <?php echo $__env->make('admin.includes.menubar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

 
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
         <!-- Bouton pour ouvrir le pop-up -->
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addListModal">
        Ajouter une liste
    </button>
      <h1>
        Listes
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo e(route('dashboardAdmin')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Listes</li>
      </ol>
    </section>


    <!-- Main content -->
    <section class="content">
    <?php if(isset($listesC) && $listesC->count() > 0): ?>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">Nom de la Liste</th>
                <th scope="col">Programme</th>
                <th scope="col">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $listesC; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $liste): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($liste->name_list); ?></td>
                    <td><?php echo e($liste->programme); ?></td>
                    <td>
                        <!-- Bouton de suppression -->
                        <form action="<?php echo e(route('deleteElecteur', $liste->id_list)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?> <!-- Utiliser DELETE au lieu de POST -->
                            <button type="submit" class="btn btn-danger" onclick="return confirm('Voulez-vous vraiment supprimer cet électeur ?')">
                                <i class="fa fa-trash"></i>
                            
                            </button>
                        </form>

                        <!-- Bouton d'édition -->
                        <a href="#" class="btn btn-secondary">
                            <i class="fa fa-pencil"></i>
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php else: ?>
    <p class="text-center">Aucun électeur trouvé.</p>
<?php endif; ?>
    </section>
  </div>
  
  <?php echo $__env->make('admin.includes.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</div>
<!-- ./wrapper -->
 <!-- Fenêtre modale -->
<div class="modal fade" id="addListModal" tabindex="-1" aria-labelledby="modalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalLabel">Ajouter une liste</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('enregistrerList')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="nom" class="form-label">Nom de la liste</label>
                        <input type="text" class="form-control" id="nom" name="nom" required>
                    </div>
                    <div class="mb-3">
                        <label for="programme" class="form-label">Programme</label>
                        <textarea class="form-control" id="programme" name="programme" rows="3" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="ufr" class="form-label">UFR</label>
                        <select class="form-select" id="ufr" name="ufr" required>
                            <option value="">Veuillez sélectionner votre UFR</option>
                            <?php $__currentLoopData = App\Models\UFR::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ufr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($ufr->nom); ?>" <?php echo e(old('ufr') == $ufr->nom ? 'selected' : ''); ?>>
                                    <?php echo e($ufr->nom); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary">Enregistrer</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<?php echo $__env->make('admin.includes.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>
</html>
<?php /**PATH C:\Users\FICKOU\Desktop\projet_Dev_WEB_23-24\voteUGB\resources\views/admin/candidates.blade.php ENDPATH**/ ?>