<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Admin UGBvote</b>
    </div>
    <strong> &copy; 2025 UGB-Vote</strong>
</footer><?php /**PATH C:\Users\FICKOU\Desktop\projet_Dev_WEB_23-24\voteUGB\resources\views/admin/includes/footer.blade.php ENDPATH**/ ?>